# LightScribe label burner: local web server for Windows PowerShell 5.1 (nothing to install).
# It hands your image to LightScribe's own print components (LSPrintDialog.exe / LSPrintingDialog.exe),
# the command-line interface described in the official LightScribe Public Windows SDK.
param([int]$Port = 8765)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing, System.Web
$origin = "http://localhost:$Port"
$script:proc = $null

function Get-LSDirs {
  $out = @()
  foreach ($view in 'Registry32', 'Registry64') {
    $k = [Microsoft.Win32.RegistryKey]::OpenBaseKey('LocalMachine', $view).OpenSubKey('SOFTWARE\LightScribe')
    if (-not $k) { continue }
    $p = $k.GetValue('LSPrintAPI')
    if (-not $p) { $s = $k.OpenSubKey('LSPrintAPI'); if ($s) { $p = $s.GetValue('') } }
    if ($p -and (Test-Path -LiteralPath $p)) { $out += (Split-Path $p) }
  }
  $out += "${env:CommonProgramFiles(x86)}\LightScribe", "$env:CommonProgramFiles\LightScribe"
  $out | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique
}

function Find-Exe($name) {
  foreach ($d in @(Get-LSDirs)) {
    $hit = Get-ChildItem -Path $d -Filter $name -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($hit) { return $hit.FullName }
  }
}

function Get-Drives {
  $i = 0
  Get-CimInstance Win32_CDROMDrive | Where-Object { $_.Drive } | Sort-Object Drive | ForEach-Object {
    [pscustomobject]@{ letter = $_.Drive.Substring(0, 1); name = "$($_.Caption) ($($_.Drive))"; index = $i++ }
  }
}

function Send($ctx, $body, $type = 'application/json', $code = 200) {
  $b = [Text.Encoding]::UTF8.GetBytes($body)
  $ctx.Response.StatusCode = $code
  $ctx.Response.ContentType = $type
  $ctx.Response.OutputStream.Write($b, 0, $b.Length)
  $ctx.Response.Close()
}

$listener = New-Object Net.HttpListener
$listener.Prefixes.Add("$origin/")
$listener.Start()
Write-Host "LightScribe label burner is running at $origin  (close this window to stop it)"
Start-Process $origin

while ($listener.IsListening) {
  $ctx = $listener.GetContext(); $req = $ctx.Request
  try {
    switch -Regex ($req.Url.AbsolutePath) {
      '^/$' { Send $ctx (Get-Content (Join-Path $PSScriptRoot 'index.html') -Raw -Encoding UTF8) 'text/html; charset=utf-8' }
      '^/api/info$' {
        $info = @{ installed = [bool](Find-Exe 'LSPrintDialog.exe'); drives = @(Get-Drives) }
        Send $ctx ($info | ConvertTo-Json -Compress -Depth 4)
      }
      '^/api/status$' {
        $p = $script:proc
        $done = [bool]($p -and $p.HasExited)
        Send $ctx (@{ running = [bool]($p -and -not $done); exitCode = $(if ($done) { $p.ExitCode }) } | ConvertTo-Json -Compress)
      }
      '^/api/burn$' {
        if ($req.HttpMethod -ne 'POST' -or $req.Headers['Origin'] -ne $origin) { Send $ctx '{"error":"Request refused."}' 'application/json' 403; break }
        if ($script:proc -and -not $script:proc.HasExited) { throw 'LightScribe is already busy with a label.' }
        $q = [Web.HttpUtility]::ParseQueryString($req.Url.Query)

        # Browser PNG -> 24-bit BMP in %TEMP% (1200 px across 120 mm = 254 dpi); LightScribe deletes it afterwards.
        $ms = New-Object IO.MemoryStream; $req.InputStream.CopyTo($ms); $ms.Position = 0
        $img = [Drawing.Image]::FromStream($ms)
        $bmp = New-Object Drawing.Bitmap $img.Width, $img.Height, ([Drawing.Imaging.PixelFormat]::Format24bppRgb)
        $bmp.SetResolution(254, 254)
        $g = [Drawing.Graphics]::FromImage($bmp); $g.Clear([Drawing.Color]::White)
        $g.DrawImage($img, 0, 0, $img.Width, $img.Height); $g.Dispose()
        $file = Join-Path $env:TEMP ('ls_{0}.bmp' -f [guid]::NewGuid().ToString('N'))
        $bmp.Save($file, [Drawing.Imaging.ImageFormat]::Bmp); $bmp.Dispose(); $img.Dispose()
        $f = $file -replace '\\', '/'

        if ($q['mode'] -eq 'direct') {
          $quality = $q['quality']; if ($quality -notin 'draft', 'normal', 'best') { $quality = 'normal' }
          $drive = $q['drive']; if ($drive -notmatch '^[A-Za-z]$') { throw 'No optical drive was selected.' }
          $name = $q['name'] -replace '[^\w\s\.\-\(\):]', ''
          $copies = [Math]::Max(1, [int]$q['copies'])
          $args1 = "--filename `"$f`" --name `"$name`" --index $([int]$q['index']) --quality $quality --path $drive --copies $copies --media 1 --deleteImageFile 1"
          $exe = Find-Exe 'LSPrintingDialog.exe'
        } else {
          $args1 = "--filename `"$f`" --deleteImageFile 1"
          $exe = Find-Exe 'LSPrintDialog.exe'
        }
        if (-not $exe) { throw 'LightScribe System Software was not found. Install it, then restart this app.' }
        $script:proc = Start-Process -FilePath $exe -ArgumentList $args1 -PassThru
        Send $ctx '{"ok":true}'
      }
      default { Send $ctx 'Not found' 'text/plain' 404 }
    }
  } catch {
    try { Send $ctx (@{ error = $_.Exception.Message } | ConvertTo-Json -Compress) 'application/json' 500 } catch {}
  }
}
